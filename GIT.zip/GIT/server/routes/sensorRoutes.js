
import express from 'express'
import { pool } from '../db.js'
import jwt from 'jsonwebtoken'

const router = express.Router()

// Verify the user's login token
function authenticateToken(req, res, next) {
  const authHeader = req.headers.authorization
  const token = authHeader && authHeader.split(' ')[1]

  if (!token) {
    return res.status(401).json({
      message: 'Authentication token required.'
    })
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET)
    req.user = decoded
    next()
  } catch {
    return res.status(403).json({
      message: 'Invalid or expired token.'
    })
  }
}

// Save a sensor reading
router.post('/', authenticateToken, async (req, res) => {
  try {
    const {
      temperature,
      humidity,
      soil_moisture,
      light_intensity,
      co2,
      water_level
    } = req.body

    if (
      temperature == null ||
      humidity == null ||
      soil_moisture == null
    ) {
      return res.status(400).json({
        message: 'Temperature, humidity and soil moisture are required.'
      })
    }

    // The token must contain the user's ID.
    const userId = req.user.userId ?? req.user.user_id

    if (!userId) {
      return res.status(401).json({
        message: 'User ID missing from login token. Please log in again.'
      })
    }

    const result = await pool.query(
      `INSERT INTO sensor_readings
       (temperature, humidity, soil_moisture, light_intensity, co2, water_level, user_id)
       VALUES ($1, $2, $3, $4, $5, $6, $7)
       RETURNING *`,
      [
        temperature,
        humidity,
        soil_moisture,
        light_intensity ?? null,
        co2 ?? null,
        water_level ?? null,
        userId
      ]
    )

    res.status(201).json({
      message: 'Sensor reading saved successfully.',
      reading: result.rows[0]
    })
  } catch (error) {
    console.error('Save sensor reading failed:', error.message)
    res.status(500).json({
      message: 'Could not save sensor reading.'
    })
  }
})

// Get the logged-in user's sensor readings
router.get('/', authenticateToken, async (req, res) => {
  try {
    const userId = req.user.userId ?? req.user.user_id

    if (!userId) {
      return res.status(401).json({
        message: 'User ID missing from login token. Please log in again.'
      })
    }

    const result = await pool.query(
      `SELECT *
       FROM sensor_readings
       WHERE user_id = $1
       ORDER BY recorded_at DESC
       LIMIT 100`,
      [userId]
    )

    res.json({ readings: result.rows })
  } catch (error) {
    console.error('Fetch sensor readings failed:', error.message)
    res.status(500).json({
      message: 'Could not fetch sensor readings.'
    })
  }
})

export default router
