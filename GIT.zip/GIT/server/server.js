
import express from 'express'
import cors from 'cors'
import dotenv from 'dotenv'
import { testDatabase, pool } from './db.js'
import authRoutes from './routes/authRoutes.js'
import sensorRoutes from './routes/sensorRoutes.js'

dotenv.config()

const app = express()
const PORT = Number(process.env.PORT || 5000)

// Allow requests from the React frontend
app.use(cors({
  origin: 'http://localhost:5173'
}))

// Parse JSON request bodies
app.use(express.json())

// Registration and login routes
app.use('/api/auth', authRoutes)
app.use('/api/sensors', sensorRoutes)

// Backend health check
app.get('/api/health', (req, res) => {
  res.json({
    message: 'AgroSense backend is running!',
    status: 'OK'
  })
})

// PostgreSQL connection check
app.get('/api/db-test', async (req, res) => {
  try {
    const result = await pool.query(
      'SELECT current_database() AS database'
    )

    res.json({
      status: 'connected',
      database: result.rows[0].database
    })
  } catch (error) {
    console.error('Database test failed:', error.message)

    res.status(500).json({
      status: 'error',
      message: 'Database connection failed'
    })
  }
})

// Connect to PostgreSQL before starting the server
async function startServer() {
  try {
    await testDatabase()

    app.listen(PORT, () => {
      console.log(
        `AgroSense backend running at http://localhost:${PORT}`
      )
    })
  } catch (error) {
    console.error('PostgreSQL connection failed:', error.message)
    await pool.end()
    process.exitCode = 1
  }
}

startServer()
