const API_URL = 'http://localhost:5000/api'

export async function registerUser(
  name: string,
  email: string,
  password: string
) {
  const response = await fetch(`${API_URL}/auth/register`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ name, email, password }),
  })

  const data = await response.json()

  if (!response.ok) {
    throw new Error(data.message || 'Registration failed')
  }

  return data
}

export async function loginUser(
  email: string,
  password: string
) {
  const response = await fetch(`${API_URL}/auth/login`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ email, password }),
  })

  const data = await response.json()

  if (!response.ok) {
    throw new Error(data.message || 'Login failed')
  }

  return data
}

export async function saveSensorReading(
  reading: {
    temperature: number
    humidity: number
    soil_moisture: number
    light_intensity: number
    co2: number
    water_level: number
  },
  token: string
) {
  const response = await fetch(`${API_URL}/sensors`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify(reading),
  })

  const data = await response.json()

  if (!response.ok) {
    throw new Error(data.message || 'Failed to save sensor reading')
  }

  return data
}

