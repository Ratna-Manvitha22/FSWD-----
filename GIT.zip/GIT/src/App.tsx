import { useEffect, useState } from 'react'
import { loginUser, saveSensorReading } from './api'


type Page =
  | 'login'
  | 'register'
  | 'dashboard'
  | 'greenhouse'
  | 'analytics'
  | 'alerts'

function App() {

  // =========================
  // PAGE
  // =========================

  const [page, setPage] = useState<Page>('login')

  // =========================
  // LOGIN
  // =========================

  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [token, setToken] = useState('')

  // =========================
  // SENSOR VALUES
  // =========================

  const [temperature, setTemperature] = useState(28)
  const [humidity, setHumidity] = useState(65)
  const [moisture, setMoisture] = useState(72)
  const [light, setLight] = useState(750)
  const [co2, setCo2] = useState(420)
  const [waterLevel, setWaterLevel] = useState(82)

  // =========================
  // EQUIPMENT
  // =========================

  const [fan, setFan] = useState(false)
  const [pump, setPump] = useState(false)

  // =========================
  // RECORDING
  // =========================

  const [recording, setRecording] = useState(false)
  const [recordTime, setRecordTime] = useState(0)
  const [readings, setReadings] = useState(0)

  // =========================
  // LIVE SENSOR SIMULATION
  // =========================

  useEffect(() => {

    if (!recording) {
      return
    }

    const timer = window.setInterval(() => {

      // Generate small random sensor changes

      setTemperature((value) =>
        Math.max(20, Math.min(40, value + (Math.random() - 0.5)))
      )

      setHumidity((value) =>
        Math.max(40, Math.min(90, value + (Math.random() - 0.5) * 2))
      )

      setMoisture((value) =>
        Math.max(30, Math.min(100, value + (Math.random() - 0.5) * 2))
      )

      setLight((value) =>
        Math.max(200, Math.min(1200, value + (Math.random() - 0.5) * 50))
      )

      setCo2((value) =>
        Math.max(300, Math.min(1000, value + (Math.random() - 0.5) * 20))
      )

      setWaterLevel((value) =>
        Math.max(0, Math.min(100, value - Math.random() * 0.5))
      )

      // Recording information

      setRecordTime((time) => time + 1)

      setReadings((count) => count + 1)
      saveSensorReading(
  {
    temperature,
    humidity,
    soil_moisture: moisture,
    light_intensity: light,
    co2,
    water_level: waterLevel,
  },
  token
).catch((error) => {
  console.error('Failed to save sensor reading:', error)
})

    }, 1000)

    return () => {
      window.clearInterval(timer)
    }

  }, [recording])

  // =========================
  // LOGIN
  // =========================

  
const login = async () => {
  if (!email.trim() || !password.trim()) {
    alert('Please enter email and password')
    return
  }

  try {
    const data = await loginUser(email, password)
    setToken(data.token)
    setPage('dashboard')
  } catch (error) {
    alert(error instanceof Error ? error.message : 'Login failed')
  }
}

  // =========================
  // START RECORDING
  // =========================

  const startRecording = () => {

    setRecording(true)
    setRecordTime(0)
    setReadings(0)

  }

  // =========================
  // STOP RECORDING
  // =========================

  const stopRecording = () => {

    setRecording(false)

  }

  // =========================================================
  // LOGIN PAGE
  // =========================================================

  if (page === 'login') {

    return (

      <div className="min-h-screen bg-gradient-to-br from-green-400 via-emerald-500 to-teal-600 flex items-center justify-center p-6">

        {/* Background decoration */}

        <div className="absolute top-10 left-10 w-32 h-32 bg-white/20 rounded-full blur-2xl"></div>

        <div className="absolute bottom-10 right-10 w-48 h-48 bg-yellow-300/20 rounded-full blur-3xl"></div>

        {/* Login Card */}

        <div className="relative w-full max-w-md">

          <div className="bg-white/95 backdrop-blur-lg rounded-3xl shadow-2xl p-8">

            {/* Logo */}

            <div className="text-center">

              <div className="mx-auto w-20 h-20 bg-gradient-to-br from-green-400 to-emerald-600 rounded-2xl flex items-center justify-center shadow-lg">

                <span className="text-5xl">
                  🌱
                </span>

              </div>

              <h1 className="text-4xl font-bold text-gray-800 mt-5">

                Agro
                <span className="text-green-600">
                  Sense
                </span>

              </h1>

              <p className="text-gray-500 mt-2">
                Smart Greenhouse Telemetry
              </p>

            </div>

            {/* Email */}

            <div className="mt-8">

              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Email Address
              </label>

              <input
                type="email"
                placeholder="Enter your email"
                value={email}
                onChange={(event) =>
                  setEmail(event.target.value)
                }
                className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500 transition"
              />

            </div>

            {/* Password */}

            <div className="mt-5">

              <label className="block text-sm font-semibold text-gray-700 mb-2">
                Password
              </label>

              <input
                type="password"
                placeholder="Enter your password"
                value={password}
                onChange={(event) =>
                  setPassword(event.target.value)
                }
                className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500 transition"
              />

            </div>

            {/* Remember */}

            <div className="flex justify-between items-center mt-4 text-sm">

              <label className="flex items-center gap-2 text-gray-600">

                <input
                  type="checkbox"
                  className="accent-green-600"
                />

                Remember me

              </label>

              <button className="text-green-600 hover:text-green-800">
                Forgot Password?
              </button>

            </div>

            {/* Login */}

            <button
              onClick={login}
              className="w-full mt-6 py-3 rounded-xl bg-gradient-to-r from-green-500 to-emerald-600 text-white font-bold text-lg shadow-lg hover:from-green-600 hover:to-emerald-700 hover:scale-[1.02] active:scale-95 transition-all"
            >
              Login →
            </button>

            {/* Register */}

            <div className="text-center mt-6">

              <p className="text-gray-500">
                Don't have an account?
              </p>

              <button
                onClick={() => setPage('register')}
                className="mt-2 font-bold text-green-600 hover:text-green-800"
              >
                Create Account
              </button>

            </div>

          </div>

          <p className="text-center text-white/90 text-sm mt-5">
            🌿 Smart farming • Better crops • Sustainable future
          </p>

        </div>

      </div>

    )
  }

  // =========================================================
  // REGISTER PAGE
  // =========================================================

  if (page === 'register') {

    return (

      <div className="min-h-screen bg-gradient-to-br from-green-400 via-emerald-500 to-teal-600 flex items-center justify-center p-6">

        <div className="w-full max-w-md bg-white rounded-3xl shadow-2xl p-8">

          <div className="text-center">

            <div className="mx-auto w-20 h-20 bg-green-100 rounded-2xl flex items-center justify-center">

              <span className="text-5xl">
                🌿
              </span>

            </div>

            <h1 className="text-3xl font-bold text-gray-800 mt-5">
              Create Account
            </h1>

            <p className="text-gray-500 mt-2">
              Join AgroSense today
            </p>

          </div>

          {/* Name */}

          <div className="mt-7">

            <label className="block text-sm font-semibold mb-2">
              Full Name
            </label>

            <input
              type="text"
              placeholder="Enter your name"
              className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:outline-none focus:ring-2 focus:ring-green-500"
            />

          </div>

          {/* Email */}

          <div className="mt-4">

            <label className="block text-sm font-semibold mb-2">
              Email
            </label>

            <input
              type="email"
              placeholder="Enter your email"
              className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:outline-none focus:ring-2 focus:ring-green-500"
            />

          </div>

          {/* Password */}

          <div className="mt-4">

            <label className="block text-sm font-semibold mb-2">
              Password
            </label>

            <input
              type="password"
              placeholder="Create password"
              className="w-full px-4 py-3 rounded-xl border border-gray-300 focus:outline-none focus:ring-2 focus:ring-green-500"
            />

          </div>

          {/* Register */}

          <button
            onClick={() => setPage('login')}
            className="w-full mt-6 py-3 rounded-xl bg-gradient-to-r from-green-500 to-emerald-600 text-white font-bold text-lg hover:scale-[1.02] transition"
          >
            Register
          </button>

          {/* Back */}

          <button
            onClick={() => setPage('login')}
            className="w-full mt-4 text-green-600 font-semibold"
          >
            ← Back to Login
          </button>

        </div>

      </div>

    )
  }

  // =========================================================
  // DASHBOARD
  // =========================================================

  return (

    <div className="min-h-screen bg-gray-100">

      {/* =====================================================
          HEADER
      ===================================================== */}

      <header className="bg-gradient-to-r from-green-700 via-emerald-600 to-teal-600 text-white px-6 py-4 flex justify-between items-center shadow-lg">

        <div>

          <h1 className="text-2xl font-bold">
            🌱 AgroSense
          </h1>

          <p className="text-green-100 text-sm">
            Smart Greenhouse Telemetry Dashboard
          </p>

        </div>

        <button
          onClick={() => setPage('login')}
          className="bg-white text-green-700 px-5 py-2 rounded-lg font-semibold hover:bg-green-50 transition"
        >
          Logout
        </button>

      </header>

      {/* =====================================================
          NAVIGATION
      ===================================================== */}

      
{/* =====================================================
    NAVIGATION
===================================================== */}

<nav className="bg-white shadow px-6 py-4 flex flex-wrap gap-6">

  <button
    onClick={() => setPage('dashboard')}
    className={page === 'dashboard' ? 'text-green-600 font-bold' : 'text-gray-500 hover:text-green-600'}
  >
    Dashboard
  </button>

  <button
    onClick={() => setPage('greenhouse')}
    className={page === 'greenhouse' ? 'text-green-600 font-bold' : 'text-gray-500 hover:text-green-600'}
  >
    Greenhouse
  </button>

  <button
    onClick={() => setPage('analytics')}
    className={page === 'analytics' ? 'text-green-600 font-bold' : 'text-gray-500 hover:text-green-600'}
  >
    Analytics
  </button>

  <button
    onClick={() => setPage('alerts')}
    className={page === 'alerts' ? 'text-green-600 font-bold' : 'text-gray-500 hover:text-green-600'}
  >
    Alerts
  </button>

</nav>


      {/* =====================================================
          MAIN
      ===================================================== */}

      <main className="p-6 max-w-7xl mx-auto">

        {/* Heading */}

        <div>

          <h2 className="text-3xl font-bold text-gray-800">
            Greenhouse Overview 🌿
          </h2>

          <p className="text-gray-500 mt-1">
            Monitor your greenhouse environment in real time.
          </p>

        </div>

        {/* ===================================================
            RECORDING
        =================================================== */}

        <div className="bg-white rounded-2xl shadow-lg p-6 mt-6">

          <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-5">

            <div>

              <h2 className="text-xl font-bold text-gray-800">
                📡 Telemetry Recording
              </h2>

              <p className="text-gray-500 mt-1">
                Start recording greenhouse sensor data.
              </p>

            </div>

            <div className="flex flex-wrap items-center gap-4">

              {/* Recording status */}

              <div className="flex items-center gap-2">

                <span
                  className={`w-3 h-3 rounded-full ${
                    recording
                      ? 'bg-red-500 animate-pulse'
                      : 'bg-gray-400'
                  }`}
                ></span>

                <span
                  className={`font-semibold ${
                    recording
                      ? 'text-red-500'
                      : 'text-gray-500'
                  }`}
                >
                  {recording
                    ? 'Recording'
                    : 'Not Recording'}
                </span>

              </div>

              {/* Start */}

              {!recording && (

                <button
                  onClick={startRecording}
                  className="bg-green-600 hover:bg-green-700 text-white font-bold px-6 py-3 rounded-xl shadow-lg transition hover:scale-105"
                >
                  ▶ Start Recording
                </button>

              )}

              {/* Stop */}

              {recording && (

                <button
                  onClick={stopRecording}
                  className="bg-red-500 hover:bg-red-600 text-white font-bold px-6 py-3 rounded-xl shadow-lg transition hover:scale-105"
                >
                  ⏹ Stop Recording
                </button>

              )}

            </div>

          </div>

          {/* Recording statistics */}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-6">

            <div className="bg-green-50 rounded-xl p-4 border border-green-100">

              <p className="text-gray-500 text-sm">
                Recording Duration
              </p>

              <p className="text-3xl font-bold text-green-600 mt-1">
                {recordTime}s
              </p>

            </div>

            <div className="bg-blue-50 rounded-xl p-4 border border-blue-100">

              <p className="text-gray-500 text-sm">
                Sensor Readings
              </p>

              <p className="text-3xl font-bold text-blue-600 mt-1">
                {readings}
              </p>

            </div>

          </div>

        </div>

        {/* ===================================================
            SENSOR CARDS
        =================================================== */}

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mt-7">

          {/* Temperature */}

          <div className="bg-white rounded-2xl shadow p-6 border-l-4 border-orange-400 hover:shadow-xl transition">

            <p className="text-gray-500">
              🌡️ Temperature
            </p>

            <h3 className="text-4xl font-bold text-orange-500 mt-3">
              {temperature.toFixed(1)}°C
            </h3>

            <p className="text-green-500 mt-2">
              ● Normal
            </p>

          </div>

          {/* Humidity */}

          <div className="bg-white rounded-2xl shadow p-6 border-l-4 border-blue-400 hover:shadow-xl transition">

            <p className="text-gray-500">
              💧 Humidity
            </p>

            <h3 className="text-4xl font-bold text-blue-500 mt-3">
              {humidity.toFixed(1)}%
            </h3>

            <p className="text-green-500 mt-2">
              ● Normal
            </p>

          </div>

          {/* Soil Moisture */}

          <div className="bg-white rounded-2xl shadow p-6 border-l-4 border-green-500 hover:shadow-xl transition">

            <p className="text-gray-500">
              🌱 Soil Moisture
            </p>

            <h3 className="text-4xl font-bold text-green-500 mt-3">
              {moisture.toFixed(1)}%
            </h3>

            <p className="text-green-500 mt-2">
              ● Optimal
            </p>

          </div>

          {/* Light */}

          <div className="bg-white rounded-2xl shadow p-6 border-l-4 border-yellow-400 hover:shadow-xl transition">

            <p className="text-gray-500">
              ☀️ Light Intensity
            </p>

            <h3 className="text-4xl font-bold text-yellow-500 mt-3">
              {light.toFixed(0)}
            </h3>

            <p className="text-gray-500 mt-2">
              Lux
            </p>

          </div>

          {/* CO2 */}

          <div className="bg-white rounded-2xl shadow p-6 border-l-4 border-purple-500 hover:shadow-xl transition">

            <p className="text-gray-500">
              🌫️ CO₂ Level
            </p>

            <h3 className="text-4xl font-bold text-purple-500 mt-3">
              {co2.toFixed(0)}
            </h3>

            <p className="text-gray-500 mt-2">
              ppm
            </p>

          </div>

          {/* Water */}

          <div className="bg-white rounded-2xl shadow p-6 border-l-4 border-cyan-500 hover:shadow-xl transition">

            <p className="text-gray-500">
              💦 Water Tank
            </p>

            <h3 className="text-4xl font-bold text-cyan-500 mt-3">
              {waterLevel.toFixed(0)}%
            </h3>

            <p className="text-green-500 mt-2">
              ● Available
            </p>

          </div>

        </div>

        {/* ===================================================
            EQUIPMENT CONTROL
        =================================================== */}

        <div className="mt-8">

          <h2 className="text-2xl font-bold text-gray-800">
            Equipment Control ⚙️
          </h2>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-5">

            {/* FAN */}

            <div className="bg-white rounded-2xl shadow p-6 flex justify-between items-center">

              <div>

                <h3 className="text-xl font-bold text-gray-800">
                  🌀 Cooling Fan
                </h3>

                <p className="text-gray-500 mt-1">
                  Status:
                  <span
                    className={`font-bold ml-1 ${
                      fan
                        ? 'text-green-600'
                        : 'text-gray-500'
                    }`}
                  >
                    {fan ? 'ON' : 'OFF'}
                  </span>
                </p>

              </div>

              <button
                onClick={() => setFan(!fan)}
                className={`px-5 py-3 rounded-xl text-white font-bold transition ${
                  fan
                    ? 'bg-red-500 hover:bg-red-600'
                    : 'bg-green-600 hover:bg-green-700'
                }`}
              >
                {fan
                  ? 'Turn OFF'
                  : 'Turn ON'}
              </button>

            </div>

            {/* PUMP */}

            <div className="bg-white rounded-2xl shadow p-6 flex justify-between items-center">

              <div>

                <h3 className="text-xl font-bold text-gray-800">
                  🚰 Water Pump
                </h3>

                <p className="text-gray-500 mt-1">
                  Status:
                  <span
                    className={`font-bold ml-1 ${
                      pump
                        ? 'text-green-600'
                        : 'text-gray-500'
                    }`}
                  >
                    {pump ? 'ON' : 'OFF'}
                  </span>
                </p>

              </div>

              <button
                onClick={() => setPump(!pump)}
                className={`px-5 py-3 rounded-xl text-white font-bold transition ${
                  pump
                    ? 'bg-red-500 hover:bg-red-600'
                    : 'bg-green-600 hover:bg-green-700'
                }`}
              >
                {pump
                  ? 'Turn OFF'
                  : 'Turn ON'}
              </button>

            </div>

          </div>

        </div>

        {/* ===================================================
            SYSTEM STATUS
        =================================================== */}

        <div className="bg-white rounded-2xl shadow p-6 mt-8">

          <h2 className="text-xl font-bold text-gray-800">
            System Status
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-5">

            <div className="bg-green-50 rounded-xl p-4">

              <p className="text-gray-500">
                Greenhouse
              </p>

              <p className="text-green-600 font-bold mt-1">
                ● Online
              </p>

            </div>

            <div className="bg-blue-50 rounded-xl p-4">

              <p className="text-gray-500">
                Sensors
              </p>

              <p className="text-blue-600 font-bold mt-1">
                ● Connected
              </p>

            </div>

            <div className="bg-yellow-50 rounded-xl p-4">

              <p className="text-gray-500">
                Alerts
              </p>

              <p className="text-yellow-600 font-bold mt-1">
                ⚠ 2 Active
              </p>

            </div>

          </div>

        </div>

      </main>

    </div>

  )
}

export default App